// ExShellShockAutpRuler.cpp : Diese Datei enthält die Funktion "main". Hier beginnt und endet die Ausführung des Programms.
//

#include <iostream>
#include "Memory.h"
#include "ShellShock.h"
#include <ctime>


Game vGame = Game();

// Simple Timer
std::clock_t timer1;
double duration;

int main()
{
    timer1 = std::clock();
    while (true)
    {
        if (duration >= 0.1f)
        {
            timer1 = std::clock();
            vGame.UpdateInput();
            // Show all Available Data
            
            if (vGame.InBattle == true)
            {
                system("cls");
                std::cout << "Window:\n";
                std::cout << "Position X : " << vGame.GameWindow.left << " Y : " 
                                             << vGame.GameWindow.top << "\n";
                std::cout << "Size W : " << vGame.GameWindow.right - vGame.GameWindow.left 
                                         << " H : " 
                                         << vGame.GameWindow.bottom - vGame.GameWindow.top
                                         << "\n\n";

                std::cout << "Wind : "      << vGame.WindIndicator.Force    << "\n";
                std::cout << "WeaponName : "<< vGame.WeaponSelector.Name    << " Stage : "
                                            << vGame.WeaponSelector.Stage   << "\n";
                std::cout << "Player : "    << vGame.PlayerList.size()      << "\n\n";
                std::cout << "A : "         << vGame.Aimer.Angle
                          << " V : "        << vGame.Aimer.Velocity << "\n\n";

                for (int i = 0; i < vGame.PlayerList.size(); i++)
                {
                    std::cout << "Addr : " << (void*)vGame.PlayerList[i].ObjectAddress << "\n";
                    std::cout << "Name : "  << vGame.PlayerList[i].Name     << "\n";
                    std::cout << "Steam : " << vGame.PlayerList[i].SteamId  << "\n";
                    std::cout << "Connect : "<< vGame.PlayerList[i].IsConnected << "\n";
                    std::cout << "Level : " << vGame.PlayerList[i].Level    << "\n";
                    std::cout << "Team : "  << vGame.PlayerList[i].Team     << "\n";
                    std::cout << "Health : "<< vGame.PlayerList[i].Health   << "\n";
                    std::cout << "Amor : "  << vGame.PlayerList[i].Amor     << "\n";
                    std::cout << "Fuel : "  << vGame.PlayerList[i].Fuel     << "\n";
                    std::cout << "A : "     << vGame.PlayerList[i].Angle << 
                                 " V : "    << vGame.PlayerList[i].Velocity << "\n";
                    std::cout << "X : "     << vGame.PlayerList[i].Position.x
                              << " Y : "    << vGame.PlayerList[i].Position.y << "\n\n";
                }
            }
            else if (vGame.LeaveBattle == true)
            {
                system("cls");
                std::cout << "Battle was left\n";
            }
        }
        duration = (std::clock() - timer1) / (double)CLOCKS_PER_SEC;
    }

    
    


}
