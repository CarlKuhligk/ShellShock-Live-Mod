#include "ShellShock.h"


// Initialize Static Variabels


//__________Vector2__________
// Methodes


//__________Aimer__________
// Methodes
AimerOBJ::AimerOBJ()
{

}

void AimerOBJ::readRawData()
{
	readBytes(ObjectAddress + 0x08, rawDataBuffer, sizeof(rawDataBuffer));

	// Doublecheck Activestate
	memcpy(&IsActivePointer, &rawDataBuffer[0x08 - 0x08], 4);
	// Aimeractive
	if (IsActivePointer != nullptr)
	{
		IsActive = true;
	}
	else
	{
		IsActive = false;
	}
}

void AimerOBJ::processData()
{
	// Read RAW Data
	memcpy(&Angle, &rawDataBuffer[0x1C - 0x08], 4);
	memcpy(&Velocity, &rawDataBuffer[0x20 - 0x08], 4);
	memcpy(&Enable, &rawDataBuffer[0x2C - 0x08], 4);

	// Translate Angle
	Angle = 90 - Angle;
	if (Angle < 0) Angle += 360;
}

//__________Player__________
int PlayerOBJ::Count = 0;

// Methodes
PlayerOBJ::PlayerOBJ(BYTE* baseAddress)
{
	// Player gets created
	Count++;

	// Set Address
	ObjectAddress = baseAddress;

	
	// read the entire PlayerDataStructure (from 0x38 to 0x8C)
	readRawData();

	if (IsConnected == true)
	{
		// Initialize String Values
		SteamId = readString(readPointer(ObjectAddress + 0x08, { 0x08 }));
		Name = readString(readPointer(ObjectAddress + 0x08, { 0x0C }));
	}
}

PlayerOBJ::~PlayerOBJ()
{
	// Player gets deleted
	Count--;
}

// Reads the entire PlayerDataStructure (from 0x30 to 0x8C)
void PlayerOBJ::readRawData()
{
	// PlayerData
	readBytes(ObjectAddress + 0x38, rawDataBuffer, sizeof(rawDataBuffer));

	// Check if the Player is connected
	memcpy(&IsConnected, &rawDataBuffer[0x50 - 0x38], 4);
	if (IsConnected != 1)
	{
		IsConnected = false;
	}

}

void PlayerOBJ::processData()
{
	// Read RAW Data
	memcpy(&Level, &rawDataBuffer[0], 4);
	memcpy(&Team, &rawDataBuffer[0x3C - 0x38], 4);
	memcpy(&Position.x, &rawDataBuffer[0x44 - 0x38], 4);
	memcpy(&Fuel, &rawDataBuffer[0x48 - 0x38], 4);
	memcpy(&Health, &rawDataBuffer[0x54 - 0x38], 4);
	memcpy(&Amor, &rawDataBuffer[0x5C - 0x38], 4);
	memcpy(&Angle, &rawDataBuffer[0x84 - 0x38], 4);
	memcpy(&Velocity, &rawDataBuffer[0x88 - 0x38], 4);
	memcpy(&LockedIn, &rawDataBuffer[0x8C - 0x38], 4);
	Hitpoints = Health + Amor;
	// Translate Position to Unitsystem (0-1)
	Position.x = Position.x * 0.001f; // translate 0-1000 to 0-1

}

//__________Terrain__________
// Methodes
TerrainOBJ::TerrainOBJ()
{

}

void TerrainOBJ::readRawData()
{
	readBytes(ObjectAddress + 0x10, rawDataBuffer, sizeof(rawDataBuffer));
}

void TerrainOBJ::processData()
{
	// Sort the RAW-Data into 
	for (int i = 0; i < 198; i++)
	{
		// Copy RawData in to LineCollider
		memcpy(&LineCollider[i].x, &rawDataBuffer[i * 8], 4);
		memcpy(&LineCollider[i].y, &rawDataBuffer[i * 8 + 4], 4);

		// Translate Data to Unitsystem
		LineCollider[i].x = LineCollider[i].x * 0.1f + 0.5f;	// translate -5 +5 to  0-1
		LineCollider[i].y = LineCollider[i].y * 0.1f + 0.5f;	// translate -5 +5 to  0-1
	}
}


//__________Wind__________
// Methodes
WindOBJ::WindOBJ()
{

}

void WindOBJ::readRawData()
{
	Force = readValue<float>(ObjectAddress);
}

void WindOBJ::processData()
{
	if (Force > 0)
	{
		ForceRight = true;
		ForceLeft = false;
	}
	else if (Force < 0)
	{
		ForceRight = false;
		ForceLeft = true;
	}
	else
	{
		ForceRight = false;
		ForceLeft = false;
	}
}

//__________WeaponSelector__________
// Methodes
WeaponSelectorOBJ::WeaponSelectorOBJ()
{

}

void WeaponSelectorOBJ::readRawData()
{
	Name = readString(readPointer(ObjectAddress + 0x0C, { 0x08 }));
	Stage = readValue<int>(ObjectAddress + 0x24);
}

void WeaponSelectorOBJ::processData()
{
	// Build WeaponID
}

//__________Game__________
// Methodes
Game::Game()
{
	InBattle = false;
	Initialize();

}

Game::~Game()
{
	CloseProcess();
}

// Read ProcessID
// Read mono.dll Base
// Find Function for Injection
// Prepare Code
// Inject Code
// Set Jump to Injected Code
void Game::Initialize()
{
	InitializeMemory();

	// Find Position Update Function Beginn
	PositionUpdateFunktionAddress = readPointer(MonoDLL + 0x1F795C, OffsetsPositionUpdateFunction) + 0x77C;
	std::cout << "HookAddress: " << (void*)PositionUpdateFunktionAddress << "\n";
	// Code to Inject Size 55 Bytes
	BYTE EAX_ExtractionCode[] = {
		0x53,                                       //1  save ebx on stack
		0x57,                                       //1  save edi on stack
		0x56,                                       //1  save esi on stack
		0xBF, 0x40, 0x00, 0x014, 0x07,              //5  index counter__________________________position to write beginns start address +0x04
		0x83, 0x3f, 0x08,                           //3  compare for jump (counterlimit 7)
		0x72, 0x06,                                 //2  jump short over reset
		0xC7, 0x07, 0x00, 0x00, 0x00, 0x00,         //6  rest counter
		0xBE, 0x44, 0x00, 0x14, 0x07,               //5  load array base________________________position to write beginns start address +0x14
		0x8B, 0xDF,                                 //2  save index counter address
		0x8B, 0x3F,                                 //2  load counter value
		0x89, 0x04, 0xBE,                           //3  copy eax to the array at index ...
		0xFF, 0x03,                                 //2  increment index counter
		0x5E,                                       //1  restore esi from stack
		0x5F,                                       //1  restore edi from stack
		0x5B,                                       //1  restore ebx from stack
		0xD9, 0x58, 0x44,                           //3  original code
		0x0F, 0xB6, 0x85, 0x27, 0xFF, 0xFF, 0xFF,   //7  original code
		0xE9, 0x00, 0x00, 0x00, 0x00,               //5  jump back to original code ___________position to write beginns start address +0x2F
		0x90, 0x90, 0x90, 0x90  //  spacer
		//array index counter = address +0x38
		//array item 0 = start address  +0x3C
		// total amout of bytes needes = 92
	};
	// Allocate Memory for the Code
	//!!!!
	CodeInjectionAddress = virtualAlloc(100);
	//!!!!

	// Prepare Code
	// Set Counteraddress
	BYTE* indexCounterAddr = CodeInjectionAddress + 0x38;
	memcpy(&EAX_ExtractionCode[4], &indexCounterAddr, 4);

	// Set Array-Baseaddress
	EAX_ExtractorArrayAddress = CodeInjectionAddress + 0x3C;
	memcpy(&EAX_ExtractionCode[20], &EAX_ExtractorArrayAddress, 4);

	// Set Jumpaddress (back to Original Code)
	BYTE* jumpBackAddr = PositionUpdateFunktionAddress + 0x0A;

	// Calculate the dictance to the destination
	jumpBackAddr = (BYTE*)(jumpBackAddr - CodeInjectionAddress - 0x33);
	memcpy(&EAX_ExtractionCode[47], &jumpBackAddr, 4);

	// Inject EAX_ExtractionCode
	writeBytes(CodeInjectionAddress, EAX_ExtractionCode, sizeof(EAX_ExtractionCode));

	// Set Jumpaddress (to Injected Code)
	BYTE JumpToExtractionCode[] = { 0xE9, 0x00, 0x00, 0x00, 0x00 };
	BYTE* jumpForwardAddr = CodeInjectionAddress;

	// Calculate the dictance to the destination
	jumpForwardAddr = (BYTE*)(jumpForwardAddr - PositionUpdateFunktionAddress - 0x05);
	memcpy(&JumpToExtractionCode[1], &jumpForwardAddr, 4);

	// Inject Code
	writeBytes(PositionUpdateFunktionAddress, JumpToExtractionCode, sizeof(JumpToExtractionCode));

	// Replace the Originalcode fragmets with nops
	BYTE ReplaceCode[] = { 0x90, 0x90, 0x90, 0x90, 0x90 };
	// Inject Code
	writeBytes(PositionUpdateFunktionAddress + 0x05, ReplaceCode, sizeof(JumpToExtractionCode));

	// Read MySteamID
	std::vector<DWORD> offsetMySteamID = { 0,0 };
	MySteamID = readString(readPointer(MonoDLL + 0x00, offsetMySteamID));
}

// Updates all Values
void Game::UpdateInput()
{

	// Read EAX_Counter and all Extracted Addresses
	BYTE* rawAddresses[8];
	readBytes(EAX_ExtractorArrayAddress, (BYTE*)&rawAddresses[0], 8 * 4);
	// Reset ArrayCounter
	writeBytes(EAX_ExtractorArrayAddress - 0x04, { 0 }, 4);

	// Aimer
	if (PlayerList.size() == 0)
	{
		// Set AimerAddress
		Aimer.ObjectAddress = readPointer(rawAddresses[0] + 0x28, { 0x08, 0x1C, 0x0C, 0x18, 0x18 });
	}
	// AimerData
	Aimer.readRawData();

	// Set the State of the Battle
	// If the Playerlist empty -Y InBattle = false
	if (Aimer.IsActive == false)
	{
		// InBattle change to false -> LeaveBattle = true
		if (InBattle == true)
			LeaveBattle = true;
		else
			LeaveBattle = false;

		InBattle = false;
	}
	else
	{
		// InBattle change to true -> EnterBattle = true
		if (InBattle == false)
			EnterBattle = true;
		else
			EnterBattle = false;

		InBattle = true;
	}


	// EnterBattle Inizialiation
	if (EnterBattle == true)
	{
		// Create Player
		// Read all Address from EAX ExtractorArray and compare to existing addresses
		// Update existing Player
		// if Address is new Create Player
		for (int i = 0; i < 8 + 1; i++)
		{
			bool playerAddressExists = false;

			if (rawAddresses[i] != nullptr)
			{
				// Compare existing Players with the EAX Addresses
				for (int j = 0; j < PlayerList.size(); j++)
				{
					if (rawAddresses[i] == PlayerList[j].ObjectAddress)
					{
						playerAddressExists = true;
						break;
					}
				}

				if (playerAddressExists == true)
				{
					// Address exists
					continue; //next address
				}
				else
				{
					// Address dont exist
					// Create Player
					PlayerOBJ newPlayer = PlayerOBJ(rawAddresses[i]);

					// Check if the Player is Connected
					if (newPlayer.IsConnected == true)
					{
						// Add Player
						PlayerList.push_back(newPlayer);
					}
				}
			}
		}

		// Initialize Adresses Terrain, Wind and Weaponselector
		Terrain.ObjectAddress = readPointer(UnityPlayerDLL + 0xFF4A74, { 0x58, 0xC0, 0x0C }) + 0x10;
		WindIndicator.ObjectAddress = readPointer(MonoDLL + 0x1F50AC, { 0x15C, 0x6C8, 0x98, 0x70 }) + 0x14;
		WeaponSelector.ObjectAddress = readPointer(UnityPlayerDLL + 0x1001D00, { 0x00, 0x2C, 0x3C }) + 0x70;
	}


	// Remove Player via Connect/Aimeractive State and
	for (int i = 0; i < PlayerList.size(); i++)
	{
		// Remove Player
		if (PlayerList[i].IsConnected == false || Aimer.IsActive == false)
		{
			// Remove Player
			PlayerList.erase(PlayerList.begin() + i);
		}
	}

	// Find MyPlayerIndex
	for (int i = 0; i < PlayerList.size(); i++)
	{
		// Compare eatch SteamID with my own
		if (strcmp(PlayerList[i].SteamId.c_str(), MySteamID.c_str()) == true)
		{
			// Found Myself
			MyPlayer = &PlayerList[i];
			MyPlayerIndex = i;
			break;
		}
		else
		{
			MyPlayerIndex = -1;
		}
	}


	// Update BattleData
	if (InBattle == true)
	{
		// Read RawData
		Terrain.readRawData();
		WindIndicator.readRawData();
		WeaponSelector.readRawData();

		// Process Data
		Aimer.processData();
		Terrain.processData();
		WindIndicator.processData();
		WeaponSelector.processData();

		// Calculate Players Y-Position
		for (int i = 0; i < PlayerList.size(); i++)
		{
			PlayerList[i].processData();
			// Calculate the index of the LinecolliderArray
			int index = PlayerList[i].Position.x / 0.00505050f;
			// Interpolate the Y-Position of the Player
			float deltaX1 = PlayerList[i].Position.x - Terrain.LineCollider[index].x;
			float deltaX2 = Terrain.LineCollider[index + 1].x - PlayerList[i].Position.x;
			float scale = deltaX1 / deltaX2;
			PlayerList[i].Position.y = 	Terrain.LineCollider[index].y +
			(Terrain.LineCollider[index + 1].y - Terrain.LineCollider[index].y) * scale;
		}
	}

	// Update Windowinformation
	readGameWindowRect(&GameWindow);

}


