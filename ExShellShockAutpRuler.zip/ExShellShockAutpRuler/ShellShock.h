#pragma once
#include "Memory.h"
#include <Windows.h>
#include <string>
#include <vector>
#include <iostream>
#include <gdiplus.h>



class Vector2
{
	// Variabels
public:
	float x, y;
};


class AimerOBJ : public MemorySSL
{
	// Variabels
private:
	BYTE rawDataBuffer[10*4]; // 0x08 to 0x30

public:
	BYTE* IsActivePointer = nullptr;
	bool IsActive = false;
	int Angle = 0;
	int Velocity = 0;
	bool Enable = false;

	// Methodes
	AimerOBJ();


	void readRawData();
	void processData();

};


class PlayerOBJ : public MemorySSL
{
	// Variabels
private:
	BYTE rawDataBuffer[22 * 4];

public:
	static int Count;
	std::string SteamId = "";
	std::string Name = "";
	Vector2 Position = Vector2();
	
	int Level = 0;
	int Team = 0;
	int Fuel = 0;
	bool IsConnected = false;
	int Health = 0;
	int Amor = 0;
	int Hitpoints = 0;
	int Angle = 0;
	int Velocity = 0;
	bool LockedIn = false;

	// Methodes
	PlayerOBJ(BYTE* baseAddress);

	// Reads the entire PlayerDataStructure (from 0x38 to 0x8C)
	void readRawData();
	// Sorts the Data in to the Class
	void processData();

	~PlayerOBJ();

};


class TerrainOBJ : public MemorySSL
{
	// Variabels
private:
	BYTE rawDataBuffer[198 * 4];

public:
	Vector2 LineCollider[198];

	// Methodes
	TerrainOBJ();

	void readRawData();
	void processData();
};

class WindOBJ : public MemorySSL
{
	// Variabels
public:
	float Force;
	bool ForceRight;
	bool ForceLeft;

	// Methodes
	WindOBJ();

	void readRawData();
	void processData();
};

class WeaponSelectorOBJ : public MemorySSL
{
public:

	std::string Name;
	int Stage = 0;
	int WeaponID;

	// Methodes
	WeaponSelectorOBJ();

	void readRawData();
	void processData();

};


class Game : public MemorySSL
{
	// Variabels
public:
	// Windowinformations
	RECT GameWindow;
	// MyPlayer
	std::string MySteamID = "";
	PlayerOBJ* MyPlayer = nullptr;
	int MyPlayerIndex = -1;
	// Gamestates
	bool EnterBattle;
	bool InBattle;
	bool LeaveBattle;
	// Ingameobjects
	AimerOBJ Aimer = AimerOBJ();
	WindOBJ WindIndicator = WindOBJ();
	TerrainOBJ Terrain = TerrainOBJ();
	WeaponSelectorOBJ WeaponSelector = WeaponSelectorOBJ();
	std::vector<PlayerOBJ> PlayerList;

	// Memoryposition
	BYTE* PositionUpdateFunktionAddress;
	BYTE* CodeInjectionAddress;
	BYTE* EAX_ExtractorArrayAddress;

	// Pointer to PrositionUpdateFunction
	std::vector<DWORD> OffsetsPositionUpdateFunction = { 0x30, 0x9A8, 0x00, 0x1C, 0x04, 0x188 };

public:
	// Methodes
	Game();
	~Game();

	void Initialize();
	void UpdateInput();


};